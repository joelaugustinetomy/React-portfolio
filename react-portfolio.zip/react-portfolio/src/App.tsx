import styles from './App.module.css'
import { About } from './componets/About/About'
import { Contact } from './componets/Contact/Contact'
import { Experience } from './componets/Experience/Experience'
import { Navbar } from './componets/Navbar/Navbar'
import { Project } from './componets/Projects/Project'
import { Hero } from './componets/hero/Hero'

function App() {
  return <div className={styles.App}> 
      <Navbar />
      <Hero />
      <About/>
      <Experience/>
      <Project/>
      <Contact/>
      </div>
}

export default App
