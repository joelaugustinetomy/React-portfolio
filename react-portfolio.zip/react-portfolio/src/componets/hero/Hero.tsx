import React from "react";
import { getImageUrl } from "../../utils";
import styles from "./Hero.module.css"

export const Hero =()=>{
    return <section className={styles.container}>
        <div className={styles.content}>
            <h1 className={styles.title}>Hi there,</h1>
            <p className={styles.description}>I am Joel, I’m diving headfirst into the world of software development. My toolbox includes JavaScript and Python, and I’m eager to learn more. Let’s build cool stuff together!</p>
            <a href="mailto:joelaugutinetomy@gmail.com" className={styles.contactBtn}>Contact Me</a>
        </div>
        <img src={getImageUrl("hero/heroImage.png")} alt="hero" className={styles.heroImg}/>
        <div className={styles.topBlur}/>
        <div className={styles.bottomBlur}/>
    </section>
}