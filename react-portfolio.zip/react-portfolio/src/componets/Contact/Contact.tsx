import React from "react";
import styles from "./Contact.module.css"
import { getImageUrl } from "../../utils";

export const Contact = () => {
    return <footer className={styles.container} id="contact">
        <div className={styles.text}>
            <h2>Contact</h2>
            <p>Feel Free to reach out </p>
        </div>
        <ul className={styles.links}>
            <li className={styles.link}>
                <img src={getImageUrl("contact/emailIcon.png")} alt="email icon"/>
                <a href="mailto:joelaugustinetomy@gmail.com">joelaugustinetomy@gmail.com</a>
            </li>
            <li className={styles.link}>
                <img src={getImageUrl("contact/linkedinIcon.png")} alt="linkedIn Icon"/>
                <a href="https://linkedin.com/in/joelaugustinetomy">linkedin.com/in/joelaugustinetomy</a>
            </li>
            <li className={styles.link}>
                <img src={getImageUrl("contact/githubIcon.png")} alt="GitHub icon"/>
                <a href="https://github.com/JoelAug3">github.com/joelaugustinetomy</a>
            </li>
            <li className={styles.link}>
                <img src={getImageUrl("contact/leetCode.png")} alt="leetcode icon"/>
                <a href="https://leetcode.com/u/Joel_AT/">leetcode.com/JoelAugustineTomy</a>
            </li>
        </ul>
    </footer>
}