import React from "react";
// import { getImageUrl } from "../../utils";
import styles from "./About.module.css"
import { getImageUrl } from "../../utils";

export const About =()=>{
    return (<section className={styles.container} id="about">
        <h2 className={styles.title}>About</h2>
        <div className={styles.content}>
            <img src={getImageUrl("about/aboutImage.png")} alt="sitting with the laptop" className={styles.aboutImage}/>
            <ul className={styles.aboutItems}>
                <li className={styles.aboutItem}>
                    <img src={getImageUrl("about/cursorIcon.png")} alt="Cursor Icon"/>
                    <div className={styles.aboutItemText}>
                        <h3>Frontend Developer</h3>
                        <p>As a frontend developer, I love creating engaging and user-friendly web interfaces. My expertise lies in HTML, CSS, and JavaScript. Let’s build something amazing together</p>
                    </div>
                </li>
                <li className={styles.aboutItem}>
                    <img src={getImageUrl("about/serverIcon.png")} alt="Cursor Icon"/>
                    <div className={styles.aboutItemText}>
                        <h3>Backend Developer</h3>
                        <p>As a backend developer, I love creating the logic and functionality of websites. My skills include connecting to databases and handling user requests. I use web frameworks and APIs to simplify tasks like authentication, routing, and database access</p>
                    </div>
                </li>
                <li className={styles.aboutItem}>
                    <img src={getImageUrl("about/cursorIcon.png")} alt="Design Icon"/>
                    <div className={styles.aboutItemText}>
                        <h3>Designer</h3>
                        <p>I believe that great design not only looks beautiful but also solves problems effectively. Whether it’s crafting a memorable logo or designing an intuitive app interface, I’m all in. Let’s create something visually captivating together! 🎨</p>
                    </div>
                </li>
            </ul>
        </div>

        
    </section>)
}